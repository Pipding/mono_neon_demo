﻿
using NeonShooter;

using var game = new NeonShooterGame();
game.Run();
